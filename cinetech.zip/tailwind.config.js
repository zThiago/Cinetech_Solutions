module.exports = {
  darkMode: true, // or 'media' or 'class'
  content: [
    "./*.html",
    "./pages/**/*.html",
    "./assets/js/**/*.js"
  ],
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
